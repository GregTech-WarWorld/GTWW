package mgKze.mod.world.dimension.withered;

import mgKze.mod.init.BiomeInit;
import mgKze.mod.init.DimensionInit;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeProviderSingle;
import net.minecraft.world.gen.IChunkGenerator;

public class DimensionWitheredLand extends WorldProvider{

	public DimensionWitheredLand(){
		this.biomeProvider = new BiomeProviderSingle(BiomeInit.WITHERED);
	}
	
	@Override
	public DimensionType getDimensionType() {
		return DimensionInit.WITHERED;
	}

	@Override
	public IChunkGenerator createChunkGenerator() {
		return new ChunkGeneratorWithered(world, true, world.getSeed());
	}
	
	@Override
	public boolean canRespawnHere() {
		return false;
	}
	
	@Override
	public boolean isSurfaceWorld() {
		return false;
	}
}
