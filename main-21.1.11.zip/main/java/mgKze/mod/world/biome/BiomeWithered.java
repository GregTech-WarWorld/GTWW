package mgKze.mod.world.biome;

import java.util.Random;

import mgKze.mod.entity.EntitymgKze;
import mgKze.mod.init.BlockInit;
import mgKze.mod.objects.blocks.BlockDirtBase;
import mgKze.mod.world.gen.generators.WorldGenWitheredTree;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStone;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenMinable;

public class BiomeWithered extends Biome {

	protected static final WorldGenAbstractTree TREE = new WorldGenWitheredTree();
	
	public BiomeWithered(BiomeProperties properties) {
		super(new BiomeProperties("Withered").setBaseHeight(0.125F).setHeightVariation(0.05F).setTemperature(2.5F).setRainfall(0.0F).setRainDisabled().setWaterColor(11957831));
		
		topBlock = BlockInit.WITHEREDDIRT.getDefaultState();
		fillerBlock = Block.getBlockFromName("minecraft:stone").getDefaultState();
		
		this.decorator.coalGen = new WorldGenMinable(Block.getBlockFromName("minecraft:coal_ore").getDefaultState(), 10);
		this.decorator.ironGen = new WorldGenMinable(Block.getBlockFromName("minecraft:iron_ore").getDefaultState(), 10);
		this.decorator.treesPerChunk = 2;
		
		this.spawnableCaveCreatureList.clear();
		this.spawnableMonsterList.clear();
		this.spawnableCreatureList.clear();
		this.spawnableWaterCreatureList.clear();
		
		this.spawnableCreatureList.add(new SpawnListEntry(EntitymgKze.class, 5, 1, 2));
		this.spawnableWaterCreatureList.add(new SpawnListEntry(EntitySquid.class, 10, 1, 5));
	}
	
	@Override
	public WorldGenAbstractTree getRandomTreeFeature(Random rand) {
		return TREE;
	}
}
