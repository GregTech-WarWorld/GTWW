package mgKze.mod.world.gen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import mgKze.mod.init.BlockInit;
import mgKze.mod.world.gen.generators.WorldGenStructure;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.item.ItemAir;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomePlains;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;

public class WorldGenCustomStructures implements IWorldGenerator{
	public static final WorldGenStructure CORRODEDBRICKHOUSE = new WorldGenStructure("corrodedbrickhouse");
	//public static final WorldGenStructure TESTSTRUCTURE = new WorldGenStructure("teststructure");

	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
		switch(world.provider.getDimension()) {
		case 1: 
			break;
		case 0:{
			generateStucture(CORRODEDBRICKHOUSE, world, random, chunkX, chunkZ, 180, Block.getBlockFromName("minecraft:grass"), BiomePlains.class);
			//generateStucture(TESTSTRUCTURE, world, random, chunkX, chunkZ, 25, Block.getBlockFromName("minecraft:grass"), BiomePlains.class);
		}
			break;
		case -1:
			break;
		default:
			break;
		}
	}
	
	private void generateStucture(WorldGenerator generator, World world, Random random, int chunkX, int chunkZ, int chance, Block topBlock, Class<?>... classes) {
		ArrayList<Class<?>> classesList = new ArrayList<Class<?>>(Arrays.asList(classes));
		
		int x = chunkX * 16 + random.nextInt(15);
		int z = chunkZ * 16 + random.nextInt(15);
		int y = calculateGenerationHeight(world, x, z, topBlock);
		BlockPos pos = new BlockPos(x,y,z);
		
		Class<?> biome = world.provider.getBiomeForCoords(pos).getClass(); 
		
		if(world.getWorldType() != WorldType.FLAT) {
			if(classesList.contains(biome)) {
				if(random.nextInt(chance) == 0) {
					generator.generate(world, random, pos);
				}
			}
		}
	}
	
	private static int calculateGenerationHeight(World world, int x, int z, Block topBlock) {
		int y = world.getHeight();
		boolean foundGround = false;
		
		while(!foundGround && y-- >= 0) {
			Block block = world.getBlockState(new BlockPos(x,y,z)).getBlock();
			foundGround = block == topBlock;
		}
		
		return y;
	}
}
