package mgKze.mod.objects.items.food;

import mgKze.mod.Main;
import mgKze.mod.init.ItemInit;
import mgKze.mod.util.interfaces.IHasModel;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;

public class ItemCustomFood extends ItemFood implements IHasModel{
	public ItemCustomFood(String name, int amount, boolean isWolfFood){
		super(amount, isWolfFood);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.GTWWTab);
		
		ItemInit.ITEMS.add(this);
	}
	
	@Override
	public void registerModels() {
		Main.proxy.registerModel(this, 0);
	}
}
