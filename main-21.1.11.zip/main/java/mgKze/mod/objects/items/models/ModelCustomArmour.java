package mgKze.mod.objects.items.models;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * ModelCustomArmour - Either Mojang or a mod author
 * Created using Tabula 7.1.0
 */
public class ModelCustomArmour extends ModelBiped {
    public ModelRenderer shape15;
    public ModelRenderer shape16;

    public ModelCustomArmour() {
    	this.textureWidth = 128;
        this.textureHeight = 128;
        this.shape16 = new ModelRenderer(this, 49, 0);
        this.shape16.setRotationPoint(-0.9F, -9.0F, 0.0F);
        this.shape16.addBox(-4.0F, 0.0F, -5.0F, 10, 3, 10, 0.0F);
        this.shape15 = new ModelRenderer(this, 0, 67);
        this.shape15.setRotationPoint(0.0F, -0.1F, 0.0F);
        this.shape15.addBox(-8.0F, -6.0F, -8.0F, 16, 1, 16, 0.0F);
        
        this.bipedHead.addChild(shape15);
        this.bipedHead.addChild(shape16);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        super.render(entity, f, f1, f2, f3, f4, f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
