package mgKze.mod.init;

import java.util.ArrayList;
import java.util.List;

import mgKze.mod.Main;
import mgKze.mod.objects.blocks.BlockBase;
import mgKze.mod.objects.blocks.BlockDirtBase;
import mgKze.mod.objects.blocks.BlockLeavesBase;
import mgKze.mod.objects.blocks.BlockLogsBase;
import mgKze.mod.objects.blocks.BlockSaplingBase;
import mgKze.mod.objects.blocks.BlockScallionPlant;
import mgKze.mod.objects.blocks.machines.advFurnace.BlockAdvancedFurnace;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.material.Material;

public class BlockInit {
	public static final List<Block> BLOCKS = new ArrayList<Block>();
	
	public static final Block GTWW_BLOCK = new BlockBase("block_gtww", Material.IRON);
	public static final Block GREGTECUM_BLOCK = new BlockBase("block_gregtecum", Material.IRON);
	public static final Block ORE_MGKZE = new BlockBase("ore_mgkze", Material.IRON);
	
	public static final Block ADVANCED_FURNACE = new BlockAdvancedFurnace("advanced_furnace");
	
	public static final Block SCALLION_PLANT = new BlockScallionPlant("scallion_plant");
	
	public static final Block ORE_END = new BlockOres("ore_end","end");
	public static final Block ORE_NETHER = new BlockOres("ore_nether","nether");
	public static final Block ORE_OVERWORLD = new BlockOres("ore_overworld","overworld");
	
	public static final Block WITHEREDPLANKS = new BlockBase("withered_plank", Material.WOOD);
	public static final Block WITHEREDLOGS = new BlockLogsBase("withered_log");
	public static final Block WITHEREDLEAVES = new BlockLeavesBase("withered_leaf");
	public static final Block WITHEREDSAPLING = new BlockSaplingBase("withered_sapling");
	public static final Block WITHEREDDIRT = new BlockDirtBase("withered_dirt", Main.GTWWTab);
}
