package mgKze.mod.init;

import mgKze.mod.Main;
import mgKze.mod.world.dimension.withered.DimensionWitheredLand;
import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;

public class DimensionInit {
	public static final DimensionType WITHERED = DimensionType.register("The Withered Land", "_withered", Main.GTWW_WORLDID, DimensionWitheredLand.class, false);
	
	public static void registerDimensions() {
		DimensionManager.registerDimension(Main.GTWW_WORLDID, WITHERED);
	}
}
