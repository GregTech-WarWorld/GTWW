package mgKze.mod.util.handlers;

import mgKze.mod.Main;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.storage.loot.LootTableList;

public class LootTableHandler {
	public static final ResourceLocation MGKZE = LootTableList.register(new ResourceLocation(Main.MODID, "mgKze"));
}
