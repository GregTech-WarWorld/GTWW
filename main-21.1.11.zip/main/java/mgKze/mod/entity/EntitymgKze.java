package mgKze.mod.entity;

import mgKze.mod.util.handlers.LootTableHandler;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntitymgKze extends EntityZombie{

	public EntitymgKze(World worldIn) {
		super(worldIn);
	}
	
	@Override
	protected boolean shouldBurnInDay() {
		return false;
	}
	
	@Override
	protected ResourceLocation getLootTable() {
		return LootTableHandler.MGKZE;
	}
}
