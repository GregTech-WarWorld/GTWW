package mgKze.mod.proxy;

import net.minecraft.item.Item;

public class CommonProxy {
	public void registerModel(Item item, int metadata) {
	}
	
	public void registerVariantRenderer(Item item, int meta, String filename, String id) {
		
	}
}
